import 'package:flutter/material.dart';

class MenuPreviewScreen extends StatelessWidget {
  const MenuPreviewScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text("Menu Preview for Customer", style: TextStyle(fontSize: 18)),
    );
  }
}
